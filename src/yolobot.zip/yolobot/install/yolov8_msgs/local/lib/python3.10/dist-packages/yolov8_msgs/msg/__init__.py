from yolov8_msgs.msg._inference_result import InferenceResult  # noqa: F401
from yolov8_msgs.msg._yolov8_inference import Yolov8Inference  # noqa: F401
