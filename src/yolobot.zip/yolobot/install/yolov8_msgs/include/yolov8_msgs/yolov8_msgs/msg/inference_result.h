// generated from rosidl_generator_c/resource/idl.h.em
// with input from yolov8_msgs:msg/InferenceResult.idl
// generated code does not contain a copyright notice

#ifndef YOLOV8_MSGS__MSG__INFERENCE_RESULT_H_
#define YOLOV8_MSGS__MSG__INFERENCE_RESULT_H_

#include "yolov8_msgs/msg/detail/inference_result__struct.h"
#include "yolov8_msgs/msg/detail/inference_result__functions.h"
#include "yolov8_msgs/msg/detail/inference_result__type_support.h"

#endif  // YOLOV8_MSGS__MSG__INFERENCE_RESULT_H_
