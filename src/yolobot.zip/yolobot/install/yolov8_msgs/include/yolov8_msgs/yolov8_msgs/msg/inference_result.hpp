// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef YOLOV8_MSGS__MSG__INFERENCE_RESULT_HPP_
#define YOLOV8_MSGS__MSG__INFERENCE_RESULT_HPP_

#include "yolov8_msgs/msg/detail/inference_result__struct.hpp"
#include "yolov8_msgs/msg/detail/inference_result__builder.hpp"
#include "yolov8_msgs/msg/detail/inference_result__traits.hpp"

#endif  // YOLOV8_MSGS__MSG__INFERENCE_RESULT_HPP_
