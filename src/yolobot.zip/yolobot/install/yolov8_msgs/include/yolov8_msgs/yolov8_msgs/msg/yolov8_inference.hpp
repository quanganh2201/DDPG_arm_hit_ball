// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef YOLOV8_MSGS__MSG__YOLOV8_INFERENCE_HPP_
#define YOLOV8_MSGS__MSG__YOLOV8_INFERENCE_HPP_

#include "yolov8_msgs/msg/detail/yolov8_inference__struct.hpp"
#include "yolov8_msgs/msg/detail/yolov8_inference__builder.hpp"
#include "yolov8_msgs/msg/detail/yolov8_inference__traits.hpp"

#endif  // YOLOV8_MSGS__MSG__YOLOV8_INFERENCE_HPP_
